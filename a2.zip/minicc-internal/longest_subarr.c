int longest_subarr(int len, int *list) {
    int count = 0;
    int max = 0;
    int i;
    for (i=1; i<len; i++) {
        if (list[i] - list[i-1] == 1) {
            count ++;
            if (count > max) {
                max = count;
            }
        }
        else {
            count = 0;
        }
    }
    return max;
}

// given an array of integers, return the length of the longest consecutive subarry

int main() {}